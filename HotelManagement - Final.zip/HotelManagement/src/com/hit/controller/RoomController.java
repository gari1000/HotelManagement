package com.hit.controller;
import com.hit.model.*;

public class RoomController {

	private String bedType;
	private String roomType;
	private String price;
	
public RoomController(String roomType, String bedType, String price) {
	
	Room room = new Room();
	room.addRoom(roomType, bedType, price);
	
	}
}
