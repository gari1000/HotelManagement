package com.hit.controller;
import java.util.ArrayList;

import com.hit.model.*;

public class ReservationController {
	
	@SuppressWarnings("unused")
	private String name;
	private String address;
	private String phone;
	private String checkin;
	private String checkout;
	private String roomType;
	private String idRoom;
	private String bedType;

	public ReservationController() {
	}
	
	
	public ReservationController(String name, String address, String phone, String checkin, String checkout, String roomType,
			String idRoom, String bedType) {
		
	 Reservation res = new Reservation();
	 res.addRes(name, address, phone, checkin, checkout, roomType, idRoom, bedType);
		
	}
	
	public void FillCombo(){
		Reservation res = new Reservation();
		res.FillCombo();
	}
		
		
		
	
	
}
