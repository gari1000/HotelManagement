package com.hit.model;

public interface Employee 
{   
	
    public static final Long id = null;
    public static final String firstName = "";
    public static final String lastName = "";
    public static final int salary=0;
    public double getHourlyRate();


}
