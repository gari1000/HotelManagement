package com.hit.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Reservation {

	private static final ResultSet NULL = null;
	private static int resId = 0;
	private String name;
	private String address;
	private String phone;
	private String checkin;
	private String checkout;
	private String roomType;
	private int idRoom;
	private String bedType;
	private int price;
	ArrayList<String> roomsType = new ArrayList<String>();
	ArrayList<Integer> roomsId = new ArrayList<Integer>();
	ArrayList<String> bedsType = new ArrayList<String>();

	public ArrayList<String> getRoomsType() {
		return roomsType;
	}

	public void setRoomsType(ArrayList<String> roomsType) {
		this.roomsType = roomsType;
	}

	public ArrayList<Integer> getRoomsId() {
		return roomsId;
	}

	public void setRoomsId(ArrayList<Integer> roomsId) {
		this.roomsId = roomsId;
	}

	public ArrayList<String> getBedsType() {
		return bedsType;
	}

	public void setBedsType(ArrayList<String> bedsType) {
		this.bedsType = bedsType;
	}

	public Reservation() {
		resId++;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCheckin() {
		return checkin;
	}

	public void setCheckin(String checkin) {
		this.checkin = checkin;
	}

	public String getCheckout() {
		return checkout;
	}

	public void setCheckout(String checkout) {
		this.checkout = checkout;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public int getIdRoom() {
		return idRoom;
	}

	public void setIdRoom(int idRoom) {
		this.idRoom = idRoom;
	}

	public String getBedType() {
		return bedType;
	}

	public void setBedType(String bedType) {
		this.bedType = bedType;
	}

	public static int getResId() {
		return resId;
	}

	public static void setResId(int resId) {
		Reservation.resId = resId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void addRes(String name, String address, String phone, String checkin, String checkout, String roomType,
			String idRoom, String bedType) {

		try {

			String myDriver = "com.mysql.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/HotelManagement";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "newuser", "password");

			String query = " insert into Reservation (resId,name, address,phone, checkin,checkout,roomType,idRoom,bedType)"
					+ " values (?,?,?,?,?,?,?,?,?)";

			// create the mysql insert preparedstatement
			PreparedStatement preparedStmt = conn.prepareStatement(query);
			preparedStmt.setInt(1, getResId());
			preparedStmt.setString(2, name);
			preparedStmt.setString(3, address);
			preparedStmt.setString(4, phone);
			preparedStmt.setString(5, checkin);
			preparedStmt.setString(6, checkout);
			preparedStmt.setString(7, roomType);
			preparedStmt.setString(8, idRoom);
			preparedStmt.setString(9, bedType);

			// execute the preparedstatement
			preparedStmt.execute();

			conn.close();
		} catch (Exception e) {
			System.err.println("Got an exception!");
			System.err.println(e.getMessage());

		}
	}

	public void FillCombo() {

		try {

			String myDriver = "com.mysql.jdbc.Driver";
			String myUrl = "jdbc:mysql://localhost/HotelManagement";
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "newuser", "password");

			String query = "select * from Room order by idRoom";

			// create the mysql insert preparedstatement
			PreparedStatement preparedStmt = conn.prepareStatement(query);
			ResultSet rs = preparedStmt.executeQuery();

			while (rs.next()) {
				// shows Name data in combobox
				// Add data to the array list
				setRoomType(rs.getString("type"));
				setIdRoom(rs.getInt("idRoom"));
				setBedType(rs.getString("bed"));

				roomsType.add(roomType);
				roomsId.add(idRoom);
				bedsType.add(bedType);

			}
			preparedStmt.close();
		}

		catch (Exception e) {
			System.err.println("Got an exception!");
			System.err.println(e.getMessage());
		}
	}

	public ResultSet getReservationData() {

		ResultSet rs = null;

		try {

//			String myDriver = "com.mysql.jdbc.Driver";
//			String myUrl = "jdbc:mysql://localhost/HotelManagement";
//			Class.forName(myDriver);
//			Connection conn = DriverManager.getConnection(myUrl, "newuser", "password");

			// DBConnection using Singelton

			DatabaseConnection conn = DatabaseConnection.getInstance();
			conn.getConnection();

			String query = "select * from Reservation";

			// create the mysql insert preparedstatement
			PreparedStatement preparedStmt = conn.getConnection().prepareStatement(query);
			rs = preparedStmt.executeQuery();

		}

		catch (Exception e) {
			System.err.println("Got an exception!");
			System.err.println(e.getMessage());
		}

		return rs;
	}

	public void Update(int resId, String name, String address, String phone, String checkin, String checkout) {

		try {

			// DB connection using Singelton

			DatabaseConnection conn = DatabaseConnection.getInstance();
			conn.getConnection();

			// create the java mysql update preparedstatement
			String query = "UPDATE Reservation SET name = ?, address = ?, phone = ?, checkin = ?, checkout=? WHERE resId = ?";

			PreparedStatement preparedStmt = conn.getConnection().prepareStatement(query);
			preparedStmt.setString(1, name);
			preparedStmt.setString(2, address);
			preparedStmt.setString(3, phone);
			preparedStmt.setString(4, checkin);
			preparedStmt.setString(5, checkout);
			preparedStmt.setInt(6, resId);

			// execute the java preparedstatement
			preparedStmt.executeUpdate();

			preparedStmt.close();

		}

		catch (Exception e) {
			System.err.println("Got an exception!");
			System.err.println(e.getMessage());

		}

	}

	public void calcAmount() {

		// DB connection using Singelton

		try {

			// DB connection using Singelton

			DatabaseConnection conn = DatabaseConnection.getInstance();
			conn.getConnection();

			// create the java mysql update preparedstatement
			String query = "select sum(price) as price from Room join Reservation where Reservation.idRoom= Room.idRoom";
			PreparedStatement preparedStmt = conn.getConnection().prepareStatement(query);

			ResultSet rs = preparedStmt.executeQuery();

			if (rs.next())
				setPrice(rs.getInt(1));

			// execute the java preparedstatement
			preparedStmt.executeQuery();
			preparedStmt.close();

		}

		catch (Exception e) {
			System.err.println("Got an exception!");
			System.err.println(e.getMessage());

		}

	}

	public void Delete(Object resId) {
		try {

			// DB connection using Singelton

			DatabaseConnection conn = DatabaseConnection.getInstance();
			conn.getConnection();

			// create the java mysql update preparedstatement
			String query = "DELETE FROM Reservation WHERE resId = ?";

			PreparedStatement preparedStmt = conn.getConnection().prepareStatement(query);
			preparedStmt.setObject(1, resId);
			
			// execute the java preparedstatement
			preparedStmt.executeUpdate();

			preparedStmt.close();

		}

		catch (Exception e) {
			System.err.println("Got an exception!");
			System.err.println(e.getMessage());

		}

	}

}
