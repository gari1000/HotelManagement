package com.hit.model;

public class FullTimeEmployee implements Employee{
	
	 private double hourlyRate;
	 
	    public FullTimeEmployee(double hourlyRate)
	    {
	       this.hourlyRate = hourlyRate;
	    }
	 
	    /*Implement the contract methods here*/
	    public double getHourlyRate()
	    {
	        return hourlyRate;
	    }
	    
}
