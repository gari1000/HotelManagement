package com.hit.model;

import org.junit.Test;

public class Testing extends Validation {
	Validation valid = new Validation();

	@Test
	public void testIsEmailValid() {

		String address = "alfoobar@walla.com";
		boolean expectedResult = true;
		boolean actualResult = valid.isValidEmailAddress(address);
		assert (expectedResult == actualResult);
	}

	@Test

	public void testIsAmountValid() {
		String amount = "-123456";
		boolean expectedResult = true;
		boolean actualResult = valid.isValidAmount(amount);
		assert (expectedResult == actualResult);
	}
	
	@Test
	
	public void testIsPasswordValid() {
		String password = "asfafa3131!";
		boolean expectedResult = true;
		boolean actualResult = valid.isValidPassword(password);
		assert (expectedResult == actualResult);
	}

}
