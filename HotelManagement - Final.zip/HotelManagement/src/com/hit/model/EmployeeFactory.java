package com.hit.model;

public class EmployeeFactory {
	public static Employee getEmployee(int hoursAllocated, double hourlyRate)
	   {
	       //do error checking here
	 
	       if(hoursAllocated >= 60)
	       {
	           return new FullTimeEmployee(hourlyRate);
	       }else
	       {
	           return new PartTimeEmployee(hourlyRate);
	       }
	   }

}
