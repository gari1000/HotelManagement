package com.hit.model;

import java.util.List;

public class Manager implements Employee {
	private List<Employee> subordinates;

	public List<Employee> getSubordinates() {
		return subordinates;
	}

	public void setSubordinates(List<Employee> subordinates) {
		this.subordinates = subordinates;
	}

	@Override
	public String toString() {
		return "Manager [subordinates=" + subordinates + ", details=" + super.toString() + "]";
	}

	@Override
	public double getHourlyRate() {
		// TODO Auto-generated method stub
		return 0;
	}
}
