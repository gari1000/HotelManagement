package com.hit.model;


public class Receptionist implements Employee {
	
	private int bonus;
	
	
	public int getBonus() {
		return bonus;
	}
	public void setBonus(int bonus) {
		this.bonus = bonus;
	}
	
	public int calcFinalsalary() {
		
		return (this.salary+this.bonus);
		
	}
	@Override
	public double getHourlyRate() {
		// TODO Auto-generated method stub
		return 0;
	}
}