package com.hit.model;

import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Room {
	private static  int roomId=0;
	private String bedType;
	private String roomType;
	private String price;

	
	public Room() {
		roomId++;
	}


	public int getRoomId() {
		return roomId;
	}


	public void setRoomId(int roomId) {
		Room.roomId = roomId;
	}



	public String getBedType() {
		return bedType;
	}

	public void setBedType(String bedType) {
		this.bedType = bedType;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
public void addRoom (String roomType, String bedType, String price) {

		try {
			
			//DB connection using Singelton
			
			DatabaseConnection conn = DatabaseConnection.getInstance();
			conn.getConnection();
			
	      String query = " insert into Room (idRoom, type,bed, price)"
	        + " values (?, ?, ?, ?)";

			// create the mysql insert preparedstatement
			PreparedStatement preparedStmt = conn.getConnection().prepareStatement(query);
			preparedStmt.setInt(1, getRoomId());
			preparedStmt.setString(2, roomType);
			preparedStmt.setString(3, bedType);
			preparedStmt.setString(4, price);

			// execute the preparedstatement
			preparedStmt.execute();

			conn.getConnection().close();
			
		} catch (Exception e) {
			System.err.println("Got an exception!");
			System.err.println(e.getMessage());
		}
	}

}
