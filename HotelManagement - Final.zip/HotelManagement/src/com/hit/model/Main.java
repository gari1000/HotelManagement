package com.hit.model;


public class Main
{

  public static void main(String[] args)
  {
	  
  }
	  
   
}