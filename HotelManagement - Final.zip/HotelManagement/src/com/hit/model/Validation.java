package com.hit.model;

public class Validation {

	public boolean isValidEmailAddress(String emailAddress) {
		// a null string is invalid
		if (emailAddress == null)
			return false;

		// a string without a "@" is an invalid email address
		if (emailAddress.indexOf("@") < 0)
			return false;

		// a string without a "." is an invalid email address
		if (emailAddress.indexOf(".") < 0)
			return false;

		return true;

	}

	public boolean isValidAmount(String amount) {

		if (amount.compareTo("0") < 0)
			return false;
		else if (amount.compareTo("99999") > 0)
			return false;
		else
			return true;
	}

	public boolean isValidPassword(String password) {

		{
			boolean valid = true;
			if (password.length() > 15 || password.length() < 8)

			{
				valid = false;
			}

			String upperCaseChars = "(.*[A-Z].*)";
			if (!password.matches(upperCaseChars)) {
				valid = false;
			}
			String lowerCaseChars = "(.*[a-z].*)";
			if (!password.matches(lowerCaseChars)) {
				valid = false;
			}
			String numbers = "(.*[0-9].*)";
			if (!password.matches(numbers)) {
				valid = false;
			}
			String specialChars = "(.*[,~,!,@,#,$,%,^,&,*,(,),-,_,=,+,[,{,],},|,;,:,<,>,/,?].*$)";
			if (!password.matches(specialChars)) {
				valid = false;
			}

			return valid;
		}

	}

}
