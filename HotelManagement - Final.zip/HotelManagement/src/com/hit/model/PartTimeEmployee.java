package com.hit.model;

public class PartTimeEmployee implements Employee {

	private double hourlyRate;
	 
    public PartTimeEmployee(double hourlyRate)
    {
        this.hourlyRate = hourlyRate;
    }
 
 
    public double getHourlyRate()
    {
        return hourlyRate;
    }

}
