package com.hit.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hit.controller.RoomController;
import com.hit.model.Validation;

import java.awt.Panel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import com.toedter.calendar.JCalendar;

public class Room_S extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtPrice;
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Room_S frame = new Room_S();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Room_S() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblRoom = new JLabel("Add Room");
		lblRoom.setBounds(183, 12, 70, 15);
		contentPane.add(lblRoom);

		JLabel lblNewLabel_1 = new JLabel("Room Type");
		lblNewLabel_1.setBounds(54, 90, 119, 15);
		contentPane.add(lblNewLabel_1);

		JLabel lblType = new JLabel("Bed Type");
		lblType.setBounds(54, 129, 92, 15);
		contentPane.add(lblType);

		JLabel lblPrice = new JLabel("Price");
		lblPrice.setBounds(55, 168, 76, 15);
		contentPane.add(lblPrice);

		txtPrice = new JTextField();
		txtPrice.setBounds(183, 166, 126, 19);
		contentPane.add(txtPrice);
		txtPrice.setColumns(10);

		JComboBox comboBed = new JComboBox();
		comboBed.setModel(
				new DefaultComboBoxModel(new String[] { "Single", "Double", "Triple", "Quad", "Queen", "King" }));
		comboBed.setBounds(183, 124, 128, 24);
		contentPane.add(comboBed);

		JComboBox comboRoom = new JComboBox();
		comboRoom.setModel(new DefaultComboBoxModel(new String[] { "Regular", "regular Suite", "Presedential suite" }));
		comboRoom.setBounds(183, 90, 128, 24);
		contentPane.add(comboRoom);

		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Validation valid = new Validation();
				if (valid.isValidAmount(txtPrice.getText()) == false) {
					JOptionPane.showMessageDialog(frame, "You entered negative price or very high price");
					txtPrice.setText("");
				}

				else {
					RoomController room = new RoomController(comboRoom.getSelectedItem().toString(),
							comboBed.getSelectedItem().toString(), txtPrice.getText());
					JOptionPane.showMessageDialog(frame, "Room was created");

				}
			}
		});
		btnSave.setBounds(31, 238, 90, 25);
		contentPane.add(btnSave);

		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFrame frmLoginSystem = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(frmLoginSystem, "Confirm if you want to exit", "Login System",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnExit.setBounds(314, 238, 108, 25);
		contentPane.add(btnExit);

		JButton btnBackToMenu = new JButton("Back to Menu");
		btnBackToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Menu();
				setVisible(false);
			}
		});
		btnBackToMenu.setBounds(148, 238, 137, 25);
		contentPane.add(btnBackToMenu);
		setVisible(true);
	}
}
