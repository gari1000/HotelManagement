package com.hit.view;

import java.awt.EventQueue;
import com.hit.controller.*;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import com.hit.model.*;

public class SignUp extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frame;
	private JTextField txtEmail;
	private JTextField txtUser;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp window = new SignUp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SignUp() {
		initialize();
	
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setVisible(true);
		frame.setBounds(200, 200, 500, 300);
		frame.getContentPane().setLayout(null);

		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(28, 61, 70, 15);
		frame.getContentPane().add(lblEmail);

		txtEmail = new JTextField();
		txtEmail.setBounds(154, 59, 114, 19);
		frame.getContentPane().add(txtEmail);
		txtEmail.setColumns(10);

		txtUser = new JTextField();
		txtUser.setBounds(154, 112, 114, 19);
		frame.getContentPane().add(txtUser);
		txtUser.setColumns(10);

		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setBounds(12, 114, 114, 15);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(12, 162, 86, 15);
		frame.getContentPane().add(lblPassword);

		JLabel lblSignUp = new JLabel("Sign Up ");
		lblSignUp.setBounds(172, 12, 96, 15);
		frame.getContentPane().add(lblSignUp);
						
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				

				Validation validate = new Validation();
				
				if (validate.isValidEmailAddress(txtEmail.getText())==false){
					JOptionPane.showMessageDialog(frame, "you must include @ an . in your email");
					txtEmail.setText("");
				}
				
				else
					if(validate.isValidPassword(txtPassword.getText())==false) {
						JOptionPane.showMessageDialog(frame, "Password must be 8-15 chars, must have one UPPER CASE and one lower case char and special char");
						txtPassword.setText("");
					}
				
				else
				{
				SignUpController signup = new SignUpController(txtUser.getText(), txtPassword.getText(),
						txtEmail.getText(), "com.mysql.jdbc.Driver", "jdbc:mysql://localhost/HotelManagement",
						" insert into users (username, email,password, create_time)" + " values (?, ?, ?, ?)");
				
				
				JOptionPane.showMessageDialog(frame, "Redirecting to Login screen...");
				new Login_S();
				frame.setVisible(false);
				}
				
			}
		});
		btnRegister.setBounds(63, 219, 117, 25);
		frame.getContentPane().add(btnRegister);

		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtEmail.setText(null);
				txtPassword.setText(null);
				txtUser.setText(null);

			}	
		});
		btnReset.setBounds(229, 219, 117, 25);
		frame.getContentPane().add(btnReset);

		txtPassword = new JPasswordField();
		txtPassword.setBounds(154, 160, 114, 19);
		frame.getContentPane().add(txtPassword);
	}
}
