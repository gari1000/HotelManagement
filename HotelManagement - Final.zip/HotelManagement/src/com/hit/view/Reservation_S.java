package com.hit.view;


import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.hit.controller.ReservationController;
import com.hit.model.Reservation;
import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Reservation_S extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtAddress;
	private JTextField txtPhone;
	private JTable table;
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reservation_S frame = new Reservation_S();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Reservation_S() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(600, 600, 1173, 591);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblCheckIn = new JLabel("Check In");
		lblCheckIn.setBounds(12, 209, 89, 15);
		contentPane.add(lblCheckIn);

		JLabel lblCheckout = new JLabel("Check out");
		lblCheckout.setBounds(12, 236, 89, 15);
		contentPane.add(lblCheckout);

		JDateChooser chooseCheckin = new JDateChooser();
		chooseCheckin.setBounds(160, 205, 133, 19);
		contentPane.add(chooseCheckin);

		JDateChooser chooseCheckout = new JDateChooser();
		chooseCheckout.setBounds(160, 236, 133, 19);
		contentPane.add(chooseCheckout);

		JLabel lblReservation = new JLabel("Reservation");
		lblReservation.setBounds(330, 12, 117, 15);
		contentPane.add(lblReservation);

		JLabel lblRes = new JLabel("Reservation No.");
		lblRes.setBounds(12, 42, 117, 15);
		contentPane.add(lblRes);

		JLabel lblName = new JLabel("Name");
		lblName.setBounds(12, 80, 70, 15);
		contentPane.add(lblName);

		JLabel lblAddres = new JLabel("Address");
		lblAddres.setBounds(12, 122, 70, 15);
		contentPane.add(lblAddres);

		JLabel lblPhone = new JLabel("Phone num.");
		lblPhone.setBounds(12, 166, 89, 15);
		contentPane.add(lblPhone);

		txtName = new JTextField();
		txtName.setBounds(160, 78, 133, 19);
		contentPane.add(txtName);
		txtName.setColumns(10);

		txtAddress = new JTextField();
		txtAddress.setBounds(160, 120, 133, 19);
		contentPane.add(txtAddress);
		txtAddress.setColumns(10);

		txtPhone = new JTextField();
		txtPhone.setBounds(160, 162, 133, 19);
		contentPane.add(txtPhone);
		txtPhone.setColumns(10);

		JLabel lblRoomType = new JLabel("Room Type");
		lblRoomType.setBounds(12, 318, 95, 15);
		contentPane.add(lblRoomType);

		Reservation res = new Reservation();
		res.FillCombo();

		JLabel lblRoomNum = new JLabel("Room No.");
		lblRoomNum.setBounds(12, 278, 89, 15);
		contentPane.add(lblRoomNum);

		JComboBox<String> comboroomType = new JComboBox<String>();
		comboroomType.setBounds(160, 313, 133, 24);
		contentPane.add(comboroomType);
		comboroomType.setModel(new DefaultComboBoxModel<String>(res.getRoomsType().toArray(new String[0])));

		JComboBox<Integer> comboRoomNumber = new JComboBox<Integer>();
		comboRoomNumber.setBounds(160, 273, 133, 24);
		contentPane.add(comboRoomNumber);
		comboRoomNumber.setModel(new DefaultComboBoxModel<Integer>(res.getRoomsId().toArray(new Integer[0])));

		JLabel lblBedType = new JLabel("Bed Type");
		lblBedType.setBounds(12, 359, 70, 15);
		contentPane.add(lblBedType);

		JComboBox<String> comboBedType = new JComboBox<String>();
		comboBedType.setBounds(160, 354, 134, 24);
		contentPane.add(comboBedType);
		comboBedType.setModel(new DefaultComboBoxModel<String>(res.getBedsType().toArray(new String[0])));
		
		comboRoomNumber.setEditable(true);
		
		comboRoomNumber.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				
				for(int i=0;i<comboRoomNumber.getItemCount();i++)
					
				if (comboRoomNumber.getSelectedIndex() == i) {
					comboroomType.setSelectedIndex(i);
					comboBedType.setSelectedIndex(i);

				}
			}
		});
		

		
		    
		JLabel lblAmount = new JLabel("Total Amount");
		lblAmount.setBounds(12, 403, 95, 15);
		contentPane.add(lblAmount);

		JLabel lbltotalAmount = new JLabel("");
		lbltotalAmount.setBounds(167, 403, 126, 24);
		contentPane.add(lbltotalAmount);
		setVisible(true);
		res.calcAmount();
		lbltotalAmount.setText(Integer.toString(res.getPrice()));

		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try {
					ReservationController res = new ReservationController(txtName.getText(), txtAddress.getText(),
							txtPhone.getText(), chooseCheckin.getDate().toString(), chooseCheckout.getDate().toString(),
							comboroomType.getSelectedItem().toString(), comboRoomNumber.getSelectedItem().toString(),
							comboBedType.getSelectedItem().toString());
					JOptionPane.showMessageDialog(frame, "Successfully Saved");

				}

				catch (Exception e) {
					System.err.println("Got an exception!");
					System.err.println(e.getMessage());
					JOptionPane.showMessageDialog(frame, "You can't leave fields empty");
				}

				table.setModel(DbUtils.resultSetToTableModel(res.getReservationData()));
				res.calcAmount();
				lbltotalAmount.setText(Integer.toString(res.getPrice()));

			}
		});
		btnSave.setBounds(297, 475, 117, 25);
		contentPane.add(btnSave);

		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				table.getSelectedRows();
				int r;

				for (r = 0; r < table.getRowCount(); r++) {

					res.Update((Integer) table.getValueAt(r, 0), table.getValueAt(r, 1).toString(),
							table.getValueAt(r, 2).toString(), table.getValueAt(r, 3).toString(),
							table.getValueAt(r, 4).toString(), table.getValueAt(r, 5).toString());
					repaint();
				}
				JOptionPane.showMessageDialog(frame, "Successfully Updated");
				frame.repaint();
				setVisible(true);

			}
		});
		btnEdit.setBounds(437, 475, 117, 25);
		contentPane.add(btnEdit);

		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				table.getSelectedRows();

				int row = table.getSelectedRow();
				int col = 0;

				res.Delete(table.getValueAt(row, col));

				JOptionPane.showMessageDialog(frame, "Successfully Deleted");
				table.setModel(DbUtils.resultSetToTableModel(res.getReservationData()));
				res.calcAmount();
				lbltotalAmount.setText(Integer.toString(res.getPrice()));

			}

		});
		btnDelete.setBounds(581, 475, 117, 25);
		contentPane.add(btnDelete);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(305, 39, 829, 424);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);

		table.setModel(DbUtils.resultSetToTableModel(res.getReservationData()));

		JButton btnBackToMenu = new JButton("Back to Menu");
		btnBackToMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new Menu();
				setVisible(false);
			}
		});
		btnBackToMenu.setBounds(733, 475, 145, 25);
		contentPane.add(btnBackToMenu);

	}
}
